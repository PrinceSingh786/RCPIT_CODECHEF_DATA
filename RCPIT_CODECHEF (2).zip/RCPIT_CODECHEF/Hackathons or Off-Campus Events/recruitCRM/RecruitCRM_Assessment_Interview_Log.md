# RecruitCRM Coding Problems

## 1. Two Sum

Given an array of integers `nums` and an integer `target`, return `true` if there are two numbers in the array that add up to the target, and `false` otherwise.

---

## 2. Fair Ration Distribution

A relief camp has `N` ration packets with given weights, and `M` families must each receive exactly one packet. Choose `M` of the `N` packets such that the difference between the heaviest and lightest packet among the chosen packets is as small as possible.

Find this minimum possible difference.

---

## 3. Majority Vote

Given an array of elements representing votes, find the candidate that appears strictly more than `N / 2` times.

---

## 4. String Rotation Check

Given two strings `A` and `B` of the same length, determine whether `B` can be obtained by cyclically rotating `A` to the left by some number of positions.

For example, rotating `"abcde"` left by `2` positions gives `"cdeab"`.

---

## 5. Subset Sum

Given an array of positive integers and a target sum, determine whether there exists a subset of the given array whose sum is exactly equal to the target.

Each element can be used at most once.

---

## 6. Greedy Algorithm Problem

A coding assessment included a problem based on the **Greedy Algorithm**.

**Exact problem statement was not provided.**
